print("a"*3)
c = "3"
print(c.isnumeric())
